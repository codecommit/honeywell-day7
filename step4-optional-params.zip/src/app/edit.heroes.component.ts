import { Component } from "@angular/core";
import { HeroService } from "./hero.service";
import { ActivatedRoute } from "@angular/router";

@Component({
    template : `
    <h2>{{ herointel +' '+ herorace }}</h2>
    `
})
export class EditHeroesComp{
    heros = [];
    param = 0;
    herointel;
    herorace;

    constructor(private hs:HeroService, private ar:ActivatedRoute){}

    ngOnInit(){
        this.heros = this.hs.getHeroes();
        this.herointel = this.ar.snapshot.params['intelligence'];
        this.herorace = this.ar.snapshot.params['race'];
        console.log(this.herointel, this.herorace);
    }

}