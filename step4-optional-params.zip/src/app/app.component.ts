import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template : `
    <h1>Main Component</h1>
    <router-outlet></router-outlet>
  `
})
export class AppComponent {
  title = 'step3-dynamic-params';
}
