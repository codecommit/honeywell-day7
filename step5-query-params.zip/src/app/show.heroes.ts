import { Component } from "@angular/core";
import { HeroServices } from "./hero.service";
import { ActivatedRoute } from "@angular/router";

@Component({
    template : `
    <input type="text" [(ngModel)]="filterString" >
    <table border="1" width="100%">
    	<thead>
    		<tr>
    			<td>Sl #</td>
    			<td>Title</td>
    			<td>Real Name</td>
    			<td>More Details</td>
    		</tr>
    	</thead>
    	<tbody>
        <tr *ngFor="let hero of heroes |  herofilter : filterString ">
          <td>{{ hero.id }}</td>
          <td>{{ hero.name }}</td>
          <td>{{ hero.biography["full-name"] }}</td>
          <td>
          <a [routerLink]="['hero']"
            [queryParams]="{ hid : hero.id, filterdata : filterString }" > {{ hero.name }}</a>
          
          </td>
        </tr>
    	</tbody>
    </table>
    `
    
})
export class ShowHeroes{
    heroes = [];
    filterString = ''
    constructor(private hs:HeroServices, private ar:ActivatedRoute){}
    ngOnInit(){
        this.heroes = this.hs.getData().heroes;
         this.filterString = this.ar.snapshot.queryParams['filterdata'] || '' ;
    }
}