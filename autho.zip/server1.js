var express = require("express");
var app = express();
var path = require("path");
//	app.locals.pretty = true; // will make the html in the template look well 

app.set('views', path.join(__dirname, '/views1'));
app.get("/", function(req, res){
	res.render("index.jade");
});

app.get("/register", function(req, res){
	res.render("register.jade");
});

app.get("/login", function(req, res){
	res.render("login.jade");
});

app.get("/profile", function(req, res){
	res.render("profile.jade");
});

app.get("/logout", function(req, res){
	res.redirect("/")
});

app.listen(3000);
console.log("server is now running on localhost : 3000");
