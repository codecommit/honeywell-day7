import { Component } from "@angular/core";
import { HeroServices } from "./hero.service";
import { ActivatedRoute } from "@angular/router";

@Component({
    template : `
    <h2> Show Details </h2>
    <a [routerLink]="['']" queryParamsHandling="preserve" >Back to list</a>
    <h3>{{ selhero }}{{ heroes[selhero-1].name }}</h3>
    
    `
})
export class ShowHero{
    selhero = 0;
    heroes = [];

    heroid = 0
    filterString = '';

  constructor( private hs:HeroServices, private ar:ActivatedRoute){  
  }

  ngOnInit(){
      this.heroes = this.hs.getData().heroes;
       this.selhero = this.ar.snapshot.queryParams['hid'];
       this.filterString = this.ar.snapshot.queryParams['filterdata'];
  }
}