import { Component, OnInit } from "@angular/core";
import { HeroService } from "./hero.service";

@Component({
    template : `
    <h1> Heroes List </h1>
    
    <table border="1" width="100%">
    	<thead>
    		<tr>
    			<td>Sl #</td>
    			<td>Title</td>
    			<td>Real Name</td>
    			<td>More Details</td>
    		</tr>
    	</thead>
    	<tbody>
        <tr *ngFor="let hero of heros">
          <td>{{ hero.id }}</td>
          <td>{{ hero.name }}</td>
          <td>{{ hero.biography["full-name"] }}</td>
          <td>
            <a [routerLink]="['hero', hero.id ]">Details</a>
          </td>
        </tr>
    	</tbody>
    </table>

    `
})
export class ShowHeroesComp implements OnInit{
    heros = [];

    constructor(private hs:HeroService){}

    ngOnInit(){
        this.heros = this.hs.getHeroes()
    }

}