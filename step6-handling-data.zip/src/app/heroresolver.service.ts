import { Injectable } from "@angular/core";
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from "@angular/router";
import { HeroServices } from "./hero.service";

@Injectable()
export class HeroResolverService implements Resolve<any> {
    constructor(private hs:HeroServices){

    }
    resolve(route : ActivatedRouteSnapshot, state : RouterStateSnapshot){
        return this.hs.getData();
    }
}