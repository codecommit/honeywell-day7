import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name : 'herofilter'
})
export class HeroFilter implements PipeTransform{
    transform(list, ...arg){
        if( arg.length <= 0 ){
            return  list
        }else{
            return list.filter(function(v){
                return v.name.toLowerCase().includes(arg[0].toLowerCase())
            })
        }
    }
}